<?php require_once 'Header.php';?>
<div class="container text-center">
    <div>
    <h2>Szobaárak</h2>
  <p>  STANDARD KÉTÁGYAS EMELETI SZOBA: 25.000 FT</p>
    <p>STANDARD KÉTÁGYAS EMELETI,TÓRA NÉZŐ,ERKÉLYES SZOBA: 45.000 FT</p>
    <p>STANDARD KÉTÁGYAS FÖLDSZINTI,ÖSSZENYITHATÓ SZOBA: 65.000 FT</p>
    <p>STANDARD FÖLDSZINTI NÉGYÁGYAS / MOZGÁSKORLÁTOZOTT: 85.000 FT</p>
</div>
<div>
    <h2>Edzőterem árak</h2>
    <p>  Csoportos foglalás /óra: 20.000 FT</p>
    <p>Napi bérlet: 5.000 FT</p>
    <p>Heti bérlet: 20.000 FT</p>
    <p>Havi bérlet: 78.000 FT</p>
</div>
<div>
    <h2>Wellness és gyógyszolgáltatások ára</h2>
    <p>Sportmasszázs, 30 perc: 5.000 FT</p>
    <p>Szolárium /5perc: 400 FT</p>
    <p>Gyógymasszázs: 8.000 FT</p>
    <p>Víz alatti csoportos gyógytorna: 1.000 FT</p>
</div>
</div>





<?php require_once 'Footer.php';?>