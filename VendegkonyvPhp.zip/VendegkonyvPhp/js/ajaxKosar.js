function kosarba(cid, mennyiseg) {
    if (mennyiseg === 0) {
        mennyiseg = $("#mennyiseg").val();
    }
    $.ajax({
        url: "control.php",
        type: "post",
        data: {
            "event": "kosárba",
            "adat": cid + "×" + mennyiseg
        },
        success: function (message) {
            kosarLista();
            alert(message);
        }
    });
}

function kosarLista() {
    $.ajax({
        url: "control.php",
        type: "post",
        data: {
            "event": "kosárlista"
        },
        success: function (message) {
            message = message.split("×"); // 0: táblázat HTML kódja, 1: összmennyiség, 2: összár
            $(".kosarLista").html(message[0]);
            $(".navbar .badge").html(message[1] + " db tétel: " + message[2] + " Ft");
            visible = parseInt(message[1]) > 0 ? "inline-block" : "none";
            $(".tovabbGomb").css("display", visible);
        }
    });
}

function kosarMod(cid, mennyiseg) {
    $.ajax({
        url: "control.php",
        type: "post",
        data: {
            "event": "kosárMod",
            "adat": cid + "×" + mennyiseg
        },
        success: function () {
            kosarLista();
        }
    });
}
