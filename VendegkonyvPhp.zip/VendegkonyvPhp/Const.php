<?php

    define("DOMAIN", "http://localhost/vendeg/");
    define("ADMIN_EMAIL", "madacsipeter93@gmail.com");

    define("HOST", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");
    define("DB_NAME", "vendeg");

    define("KB", "<>");
    define("NB", mb_strtoupper(KB));
    define("SZ", "0123456789");
    define("IJ", ".,:*/+-!?()[]{}_<>'\"");
    define("MIT", array("<",">"));
    define("MIRE", array("d", "s"));

    
    
    ?>

