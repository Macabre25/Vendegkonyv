
            
<?php
require_once("control.php");
// Menüpontok
$menu = array(
    array("Kezdőlap", "index"),
    array("Rólunk", "Rolunk"),
    array("Kapcsolat", "Kapcsolat"),
       array("Vendégkönyv", "Vendegkonyv"),
    array("Heti menü", "Hetimenu"),
     array("Rendezvények", "Rendezvenyek"),
     array("Szervezések", "Szervezes"),
     array("Áraink", "Ar")
);


?>

<!DOCTYPE html>
<html lang="hu">

        <head>
      
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    </head>

    <body style="font-family: Tahoma; margin-top: 70px;background-color: rosybrown;">
       
        <header>
            <nav class="navbar navbar-default navbar-fixed-top container ">
                <div class="container-fluid">
                    <div class="navbar-header bg-sky">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span> 
                        </button>
                    </div>
                    <div class="collapse navbar-collapse ">
                        <ul class="nav navbar-nav ">
<?php
                            foreach ($menu as $anyMenu) {
                                $className = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME) == $anyMenu[1] ? ' class="active"' : "";
                                echo '<li' . $className . '><a href="' . $anyMenu[1] . '.php">' . $anyMenu[0] . '</a></li>';
                            }
?>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>
        
        <h1 class="text-center">Kecskeméti hotelünk!</h1>   