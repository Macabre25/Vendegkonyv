<?php require_once 'Header.php';?>

<div class="container">
    
    
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sed vestibulum sapien. Donec varius cursus nulla, a dictum ligula. Ut dictum libero in consectetur tristique. Phasellus sollicitudin cursus lacus, et iaculis ante scelerisque non. Aliquam pulvinar diam ac tortor viverra, eget venenatis leo sollicitudin. Nulla ut vulputate urna. Donec laoreet turpis ante, nec congue turpis pharetra nec. Fusce tempor convallis lorem ut vehicula. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vestibulum eget rutrum lorem, blandit gravida nibh.</p>
    <img class="container" src="img/Kecskemét_kilátás.jpg" alt="Kecskemét kilátás"/>
    <p class="text-center">Kecskemét kilátás</p>
    <p>orem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sed mattis ligula, sit amet facilisis neque. Maecenas auctor tortor eu dolor sodales, at volutpat elit vehicula. Ut elementum semper massa, quis porta mauris posuere sed. Interdum et malesuada fames ac ante ipsum primis in faucibus. Curabitur et sem faucibus, viverra lorem ut, accumsan urna. Quisque non ligula sit amet tortor mollis auctor. Vestibulum rhoncus eros vel fermentum porttitor. Interdum et malesuada fames ac ante ipsum primis in faucibus.</p>
    <img class="container" src="img/Megyeszékhelyek_-_Bács-Kiskun_megye_-_Kecskemét.jpg" alt="Megyeszékhelyek - Bács-Kiskun megye - Kecskemét"/>
     <p class="text-center">Megyeszékhelyek - Bács-Kiskun megye - Kecskemét</p>
    <p>Nam gravida quam at cursus accumsan. Nunc convallis felis sit amet feugiat venenatis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris tincidunt nisl eget nisl fringilla, nec porta magna convallis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce fringilla fringilla lacus id tempus. Vivamus malesuada, mi non tincidunt ultrices, mauris lacus commodo est, quis aliquet nibh turpis et lectus. Nunc ultrices malesuada gravida. Proin aliquam tellus sapien, at pulvinar lorem interdum eget. Fusce eget libero faucibus, condimentum augue eget, dignissim dui. Vestibulum imperdiet a nisl et dictum. Vestibulum eleifend tincidunt tortor, vel pharetra nisl sollicitudin eget. Praesent et risus et ex pretium auctor quis vitae lectus. Nam vel gravida ipsum, in consequat lacus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    <img class="container" src="img/Trianon-emlékmű_a_szétszabdalt_Nagy-Magyarországgal_és_az_angyalos_címerrel_a_kecskeméti_Városháza_mellett.jpg" alt="Trianon-emlékmű a szétszabdalt Nagy-Magyarországgal és az angyalos címerrel a kecskeméti Városháza mellett"/>
     <p class="text-center">Trianon-emlékmű a szétszabdalt Nagy-Magyarországgal és az angyalos címerrel a kecskeméti Városháza mellett</p>
    <p>Sed pulvinar mi sem, eu cursus diam sagittis vitae. Ut ex nulla, suscipit id enim vitae, maximus gravida turpis. Etiam suscipit augue eget elementum pulvinar. Suspendisse potenti. Vivamus luctus finibus vehicula. In ut justo a dolor ornare aliquet id eget diam. Etiam interdum tristique iaculis. Aenean neque sem, condimentum sit amet neque non, bibendum tempor massa. Mauris nisi nibh, maximus at enim eu, egestas pulvinar ipsum. Donec eget faucibus turpis, non aliquam lorem. Morbi finibus lectus eu felis placerat convallis. Cras eget elit eu elit tincidunt fringilla ac eget orci.</p>
    <img class="container" src="img/Kecskemét_Főtere_a_Nagytemplom_tornyából.jpg" alt="Kecskemét Főtere a Nagytemplom tornyából"/>
     <p class="text-center">Kecskemét Főtere a Nagytemplom tornyából</p>
    <p>Donec molestie turpis vitae congue placerat. Fusce congue finibus auctor. Duis ultrices feugiat dolor, sed laoreet urna efficitur at. Morbi eget tincidunt leo. Integer sodales viverra eros nec dapibus. Donec nec elit metus. Cras sed auctor purus, in aliquam metus. Morbi euismod tortor eu tellus tristique scelerisque. Phasellus eu magna lorem. Ut volutpat nibh sem, ut tincidunt quam porta id. Etiam vel eleifend ante, eget pellentesque nulla.</p>
       
</div>






     
<?php require_once 'Footer.php';?>
