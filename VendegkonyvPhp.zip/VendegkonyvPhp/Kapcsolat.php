<?php require_once 'Header.php';?>

<div class="text-center">
    <h4>Szállodaigazgató</h4>
    <p>Név:Füles András</p>
    <p>Telefon:123456789</p>
    <p>Email:asdasdasdas@gmail.com</p>
    <h4>Szállodaigazgató helyettes</h4>
       <p>Név:Füles Csaba</p>
    <p>Telefon:125323259</p>
    <p>Email:asdasdasdas@gmail.com</p>
    <h4>Recepció</h4>
    <p>Telefon:111333444</p>
    <p>Email:asdasdasdas@gmail.com</p>
    <h4>Back office</h4>
    <p>Telefon:111333445</p>
    <p>Email:asdasdasdas@gmail.com</p>
    <h4>Karbantartó</h4>
    <p>Telefon:111333446</p>
    <p>Email:asdasdasdas@gmail.com</p>

</div>






<?php require_once 'Footer.php';?>
