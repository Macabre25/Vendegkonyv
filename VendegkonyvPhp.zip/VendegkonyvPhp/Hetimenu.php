<?php require_once 'Header.php';?>


       <h1 class="text-center">Heti étlap</h1>
      
        <div class="container">
            <hr>
        <hr>
          
            <p>Hétfő</p>
            
            <ul>
                <li>Újházi tyúkhúsleves </li>
                <li>Sült csirkecomb,rizi-bizi</li>
                <li>Túró rudi</li>
            </ul>
            <hr>
        </div>
        
         <div class="container">
          
           <p>Kedd</p>
            
            <ul>
                <li>Babgulyás</li>
                <li>Mákos tészta</li>
                <li>Alma</li>
            </ul>
            <hr>
         </div>
         
         <div class="container">
            
              <p>Szerda</p>
             <ul>
                <li>Ponty halászlé</li>
                <li>Rakott burgonya</li>
                <li>Szőlő</li>
            </ul>
              <hr> 
         </div>
        
         <div class="container">
           
              <p>Csütörtök</p>
           <ul>
                <li>Csontleves</li>
                <li>Bécsi szelet,sült burgonya</li>
                <li>Uborkasaláta</li>
            </ul>
              <hr>
         </div>
        
         <div class="container">
             
              <p>Pénter</p>
           <ul>
                <li>Tojásleves</li>
                <li>Borsófőzelék,sült virsli</li>
                <li>Kókuszgolyó</li>
            </ul> 
              <hr>
         <hr>
         </div>
         <div class="container">
           
              <h3 class="text-center">Napi ár:  999 Ft*</h3>
              <h3 class="text-center">Heti ár:<del> 4.995 Ft*</del></h3>
              <h3 id="egy" class="text-center">  4.500 Ft*</h3>
              <p><small><sup>*</sup>Csak dolgozóknak,csak helyben fogyasztva!</small></p>
              <hr id="ide">
         <p>Az étlapváltozás jogát fenntartjuk!</p>
         <hr>
         <hr> 
         <p class="text-right">@Vasmunkás étterem</p>
         </div>


<?php require_once 'Footer.php';?>
