<?php

  session_start();

  require_once 'Const.php';
  require_once 'Connect.php'; 

  function Fog($fog,$fog1){
      echo $Er= $fog1-$fog;
  }




  $pEvent = filter_input(INPUT_POST, "event", FILTER_SANITIZE_SPECIAL_CHARS);
 $gEvent = filter_input(INPUT_GET, "event", FILTER_SANITIZE_SPECIAL_CHARS);
  $latnev = filter_input(INPUT_POST, "nev", FILTER_SANITIZE_SPECIAL_CHARS);
   $szid = filter_input(INPUT_POST, "szid", FILTER_SANITIZE_SPECIAL_CHARS);
    settype($szid, "integer");
    $targy = filter_input(INPUT_POST, "targy", FILTER_SANITIZE_SPECIAL_CHARS);
  $szöveg = filter_input(INPUT_POST, "szoveg", FILTER_SANITIZE_SPECIAL_CHARS);
$uzenet = "";
   if ($pEvent === "Vendegkonyv" )
   {
       
       $datumido = date("Y.m.d H:i:s");
       $sql = "INSERT INTO latogato (szid,latneve,szovtargy,szoveg,bejido) VALUES ('$szid', '$latnev', '$targy',$szöveg,'$datumido')";
        mysqli_query($dbc, $sql);
        $uzenet= 'Az üzenet el lett küldve!';
       
 
   }  
   
   
   
   
   
   
   
   ?>