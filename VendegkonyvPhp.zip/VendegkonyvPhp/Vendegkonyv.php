
<?php require_once 'Header.php';?>

<div class="container">
        <h1 class="text-center">Vendég könyv</h1>
        <form class="col-sm-6 col-sm-push-3" method="post">
            <div class="form-group">
                <label for="nev">Név:</label>
                <input type="text" class="form-control" name="nev" id="nev" placeholder="Név" value="<?php echo $latnev; ?>" autofocus required>
            </div>
            <div class="form-group">
                <label for="targy">Tárgy:</label>
                <input type="targy" class="form-control" name="targy"  placeholder="Tárgy" value="<?php echo $targy; ?>" required>
            </div>  
           <div class="form-group">
              
                  <input type="text" class="form-control " name="szoveg"  placeholder="Szöveg" maxlength="500" value="<?php
                  echo $szöveg;
                  ?>" required>
            </div>  
         </div>
            <div class="checkbox text-center">
                <label><input type="checkbox" name="elfogad"  value="1" required> Elolvastam és elfogadom a <a href="#">felhasználási feltételek</a>et.</label>
            </div>
            <div class="form-group text-center">
                <input type="hidden" name="event" id="event" value="Vendegkonyv">
                <button type="submit" class="btn btn-success">Küldés</button>
            </div>
        </form>
    </div>
        
        <?php require_once 'Footer.php'; ?>
